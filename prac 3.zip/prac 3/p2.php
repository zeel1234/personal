<html>
<body>
<?php
     $a=47;
     echo "Decimal to Binary conversion of $a = " . decbin($a)."<br> <br>";
     $b=11001101101.10101;
     echo "Binary to Decimal conversion of $b = " . bindec($b);
?>
</body>
</html>