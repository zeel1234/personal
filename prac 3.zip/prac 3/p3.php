<html>
<body>
<?php 
	$array_first = array('Priyanshi' => '01' ,'Zeel' => '02' );
	foreach ($array_first as $rollno=> $name) {
		echo $rollno . "=>" .$name ."<br>";
		# code...
	}
	echo "<br>";
	$array_sec = array($rollno => 78, $rollno=> 88 );
	foreach ($array_sec as $rollno => $marks) {
		echo $rollno . "=>" .$marks ."<br>";
		# code...
	}
?>
</body>
</html>