<?php  $first_array = array("key1" => "the first element", "key2" => "the second element");  
 
$second_array = array(      "key3" => "this is the first element of the second array",      "key4" => "this is the second element of the second array",  );  echo $first_array['key1'];      echo $second_array['key3'];     echo $first_array['key2'];     echo $second_array['key4'];    ?> 