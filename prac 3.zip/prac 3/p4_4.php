<?php  $seven = 7;  $arrayname = array( "this is an element", 5, $seven );  
 echo $arrayname[0];   //prints: this is an element 
  echo $arrayname[1];   //prints: 5  
  echo $arrayname[2];   //prints: 7 
  ?> 