<html>
<body>
<?php
		$principal=100;
		$rate=15/100;
		$period=6;

		$s_i=$principal * (1+$rate);
		echo "Simple Interest =  ". $s_i . "  Rs"."<br>";
?>
</body>
</html>