D:\java_ma011\static.java:15: error: class B is public, should be declared in a file named B.java
public class B
       ^
1 error

Tool completed with exit code 1
