public class Multi{
	public static void main(String b[])
	{
		int a=Integer.parseInt(b[0]);
		for(int i=1;i<=10;i++)
		{
			System.out.println(a+"*"+i+"="+a*i);
		}

	}
}