class A
{
	static int a=10;
	public int b=10;
	void get()
	{
	int a=10;
	System.out.println("a="+a);
	}
	void display()
	{
	System.out.println("b="+b);
	}
}
public class B
{
	public static void main(String args[])
	{
	A a1=new A();
	a1.get();
	System.out.println("a="+a1.a);
	System.out.println("a="+A.a);
}
}