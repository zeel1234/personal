import java.util.*;
public class Area{
	public static void main(String args[])
	{
		Scanner s=new Scanner(System.in);
		System.out.println("enter a=");
		int no=s.nextInt();
	//	Scanner p=new Scanner(system.in);
		System.out.println("enter b=");
		int noo=s.nextInt();
	/*	int a=Integer.parseInt(args[0]);
		int b=Integer.parseInt(args[1]);*/
		System.out.println("area="+no*noo);
	}
}