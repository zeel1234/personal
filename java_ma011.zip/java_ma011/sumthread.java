class thread1 extends Thread
{
	 private Thread t;
	 public int sum;
	String name;

	thread1(String threadname)
	{
	     name=threadname;
	     System.out.println("Creating " +  name );
	}
	public void run()
	{
		System.out.println("Running " +  name );

	}
	int add()
	{
		for(int i=1;i<=10000;i++)
		{
			sum=sum+i;
		}
		return sum;
	}
public void start()
{
	 System.out.println("Starting " +  name );
	  if (t == null)
	  {
	      t = new Thread (this, name);

		  t.start ();


         }
	}
}


class thread2 extends Thread
{
	 private Thread t;
	 public int sum;
	String name;

	thread2(String threadname)
	{
	     name=threadname;
	     System.out.println("Creating " +  name );
	}
	public void run()
	{
		System.out.println("Running " +  name );

	}
	int add()
	{
		for(int i=10001;i<=20000;i++)
		{
			sum=sum+i;
		}
		return sum;
	}
public void start()
{
	 System.out.println("Starting " +  name );
	  if (t == null)
	  {
	      t = new Thread (this, name);

		  t.start ();


         }
	}
}

class thread3 extends Thread
{
	 private Thread t;
	 public int sum;
	String name;

	thread3(String threadname)
	{
	     name=threadname;
	     System.out.println("Creating " +  name );
	}
	public void run()
	{
		System.out.println("Running " +  name );

	}
	int add()
	{
		for(int i=20001;i<=30000;i++)
		{
			sum=sum+i;
		}
		return sum;
	}
public void start()
{
	 System.out.println("Starting " +  name );
	  if (t == null)
	  {
	      t = new Thread (this, name);

		  t.start ();
	  }
}
}

public class sumthread
{
	public static void main(String args[])
	{
		int s;
		thread1 t1=new thread1("thread1");
		t1.start();
		System.out.println(t1.add());;
		thread2 t2=new thread2("thread1");
		t2.start();
		System.out.println(t2.add());;
		thread3 t3=new thread3("thread1");
		t3.start();
		System.out.println(t3.add());;
		s=t1.sum+t2.sum+t3.sum;
		System.out.println("final sum="+s);
	}
}