public class Pattern{
	public static void main(String Args[])
	{
		for(int i=1;i<=3;i++)
		{
			for(int j=1;j<=i;j++)
			{


				 System.out.print("A");
				 /*if(i<=(2*3)-j)
				 System.out.print(" ");

				 else
				 System.out.print("A");*/

			}
			for(int k=i;k>=0;k--)
				if(k>


			System.out.print("\n");
		}

	}
}