import java.util.*;
class A extends Exception
{
	String name;
	int sem;

		public void getdata()
		{
			try{
			Scanner s1=new Scanner(System.in);
			System.out.println("Enter username=");
			name=s1.next();
			System.out.println("Enter Semester=");
			sem=s1.nextInt();
			}
			catch(InputMismatchException msg)
			{
				System.out.println("message=" + msg.toString());
			}
			catch(NumberFormatException ee)
			{
				System.out.println("message="+ee.toString());
			}

			catch(Exception e)
			{
				System.out.println("message="+e.toString());
			}


			finally
			{
				System.out.println("Bye...");
			}
	}
}

public class Validation
{
	public static void main(String args[])
	{
		A a1=new A();
		a1.getdata();
	}
}




