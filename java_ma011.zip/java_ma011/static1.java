
class A
{
	static final int a=10;
	public int b=20;
	void get()
	{
	int a=30;
	System.out.println("a="+a);
	}
	void display()
	{
	System.out.println("b="+b);
	}
}
public class static1
{
	public static void main(String args[])
	{
	A a1=new A();
	a1.get();
	a1.display();

	System.out.println("a="+a1.a);
}
}