import java.applet.*;
import java.awt.*;
public class awt1 extends Applet
{
	public void paint(Graphics g)
	{
		String c1;
		c1=getParameter("background");
		int result=Integer.parseInt(c1);

		Color c2=new Color(result);
		//g.drawString(c2,50,70);
		setBackground(c2);
	}
}