class thread1 extends Thread
{
	 private Thread t;

	String name;
	int priority;
	thread1(String threadname)
	{
	     name=threadname;
	     System.out.println("Creating " +  name );
	}
	public void run()
	{
		System.out.println("Running " +  name );

	     try
	     {
	         for(int i = 1; i <=5; i++) {
	            System.out.println("Thread: " + name + ", " + i);

	            Thread.sleep(1000);
	      }
	  }
	      catch (InterruptedException e)
	      {
		          System.out.println(  name + " interrupted.");
		  }
		//  System.out.println(name);

	}



   public void start()
 	{
         System.out.println("Starting " +  name );
         if (t == null)
         {
            t = new Thread (this, name);
            System.out.println("just after start(), T1.isAlive() = " + t.isAlive());

            t.start ();
            System.out.println("just after start(), T1.isAlive() = " + t.isAlive());

         }
	}
}
class thread2 extends Thread
{
private Thread t;

	String name;
	int priority;
	thread2(String threadname)
	{
	     name=threadname;
	     System.out.println("Creating " +  name );
	}
	public void run()
	{
		System.out.println("Running " +  name );
	     try
	     {
	         for(int i = 1; i <=6; i++)
	         {
	            System.out.println("Thread: " + name + ", " + i);
	            Thread.sleep(2000);
	     	 }
	  	}
	     catch (InterruptedException e)
	     {
		        System.out.println(  name + " interrupted.");
		 }
	}
		public void start()
		{
		     System.out.println("Starting " +  name );
		     if (t == null)
		     {
		         t = new Thread (this, name);
		         System.out.println("just after start(), T2.isAlive() = " + t.isAlive());
		         t.start ();
		         System.out.println("just after start(), T2.isAlive() = " + t.isAlive());

       		}

			}


}
class thread3 extends Thread
{
private Thread t;

	String name;
	int priority;
	thread3(String threadname)
	{
	     name=threadname;
	     System.out.println("Creating " +  name );
	}
	public void run()
	{
		System.out.println("Running " +  name );
		try
	     {
	         for(int i = 1; i <=7; i++) {
	            System.out.println("Thread: " + name + ", " + i);

	            Thread.sleep(3000);
	      }
	  }

	      catch (InterruptedException e)
	      {
		          System.out.println(  name + " interrupted.");
		  }


	}
	public void start()
	{
		System.out.println("Starting " +  name );
		if (t == null)
		{
			   t = new Thread (this, name);
			   System.out.println("just after start(), T3.isAlive() = " + t.isAlive());
			   t.start ();
			   System.out.println("just after start(), T3.isAlive() = " + t.isAlive());

	       }

	}
}



public class thread {

   public static void main(String args[]) {
     thread1 T1 = new thread1( "Thread-1");
     T1.setPriority(2);
     System.out.println("Priority of thread t1 is: " + T1.getPriority());
	 T1.start();
	 thread2 T2 = new thread2( "Thread-2");
	 T2.setPriority(1);
     System.out.println("Priority of thread t1 is: " + T2.getPriority());
     T2.start();
     thread3 T3 = new thread3( "Thread-3");
     T3.setPriority(3);
     System.out.println("Priority of thread t1 is: " + T3.getPriority());
     T3.start();

   }
}



