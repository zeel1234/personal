import java.sql.*;
import java.util.*;
class Studemt
{
	public static void main(String args[])
	{
		try{
		Scanner s1=new Scanner(System.in);
		System.out.println("1) insert data");
		System.out.println("2) delete data");
		System.out.println("3) update data");
		System.out.println("4) display data");
		System.out.println("enter your choice=");
		int ch;
		ch=s1.nextInt();

		do
		{
			switch(ch)
			{
				case 1:
					int id;
					String fname,sname,branch,sem,city,pno;

					System.out.println("enter id=");
					id=s1.nextInt();
					System.out.println("enter name=");
					fname=s1.next();
					System.out.println("enter sname=");
					sname=s1.next();
					System.out.println("enter banch=");
					branch=s1.next();
					System.out.println("enter sem=");
					sem=s1.next();
					System.out.println("enter city=");
					city=s1.next();
					System.out.println("enter pno=");
					pno=s1.next();

						Class.forName("com.mysql.jdbc.Driver");
						Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3308/student1","root","");
						Statement stmt=con.createStatement();
						String query="INSERT INTO user (s_id, fname, surname,branch,semester,city,phoneno) VALUES (?,?,?,?,?,?,?)";
						PreparedStatement preparedStatement = con.prepareStatement(query);


					    preparedStatement.setInt(1,id);
		 				preparedStatement.setString(2,fname);
		 				preparedStatement.setString(3,sname);
		 				preparedStatement.setString(4,branch);
						preparedStatement.setString(5,sem);
		 				preparedStatement.setString(6,city);
		  				preparedStatement.setString(7,pno);
						preparedStatement.execute();
					case 2:

							System.out.println("enter id=");
							int iid=s1.nextInt();
							Class.forName("com.mysql.jdbc.Driver");
							Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3308/student1","root","");
							Statement stmt1=conn.createStatement();
							String query1 = "delete from users where id = ?";
							PreparedStatement preparedStmt = conn.prepareStatement(query1);
							preparedStmt.setInt(1, iid);
				}


			}while(ch!=5);
	}
		catch(Exception e)
		{
			System.out.println(e);
		}

	}
}