<!DOCTYPE html>
<html>
<head>
	<title>student page</title>
</head>
<body>
<h1 align="center">STUDENT FORM</h1>
<table align="center">
<form action="p2.php"  method="post" enctype="multipart/form-data"> 
	<tr>
		<td>
			<label for="name">NAME:</label>
		</td>
		<td>
			<input type="text" name="name" id="name">
		</td>
	</tr>
	<tr>
		<td>
			<label for="ex _no">EXAM_NO:</label>
		</td>
		<td>
			<input type="text" name="ex_no" id="ex_no">
		</td>
	</tr>
	<tr>
		<td>
			<label for="course">SELECT COURSE:</label>
		</td>
		<td>
			<select id="course" name="course">
				<option>---SELECT COURSE---</option>
				<option value="bca">BCA</option>
				<option value="mca">MCA</option>
				<option value="bba">BBA</option>
				<option value="mba">MBA</option>
					
				
			</select>
		</td>
	</tr>
	<tr>
		<td>
			<label for="sem">SELECT SEMESTER:</label>
		</td>
		<td>
			<select id="sem" name="sem">
				<option>---SELECT SEMESTER---</option>
				<option value="1">1</option>
				<option value="2">2</option>
				<option value="3">3</option>
				<option value="4">4</option>
					
				
			</select>
		</td>
	</tr>
	<tr>
		<td>
			<label for="s1">SUBJECT 1 MARKS:</label>
		</td>
		<td>
			<input type="text" name="s1" id="s1">
		</td>
	</tr>
	<tr>
		<td>
			<label for="s2">SUBJECT 2 MARKS:</label>
		</td>
		<td>
			<input type="text" name="s2" id="s2">
		</td>
	</tr>
	<tr>
		<td>
			<label for="s3">SUBJECT 3 MARKS:</label>
		</td>
		<td>
			<input type="text" name="s3" id="s3">
		</td>
	</tr>
	<tr>
		<td>
			<label for="s4">SUBJECT 4 MARKS:</label>
		</td>
		<td>
			<input type="text" name="s4" id="s4">
		</td>
	</tr>
	<tr>
		<td>
			<label for="s5">SUBJECT 5 MARKS:</label>
		</td>
		<td>
			<input type="text" name="s5" id="s5">
		</td>
	</tr>	
	<tr>
		<td>
			<label for="file">SELECT FILE:</label>
		</td>
		<td>
			<input type="file" name="file" id="file">
		</td>
	</tr>	
	<tr>
		<td>
		</td>
		<td>
			<input type="submit" name="sub" id="sub" value="submit">
		</td>
	</tr>	
</form>
	
</table>

</body>
</html>
