<?php
if(isset($_POST['sub']))
{
	// print_r($_POST);
	// print_r($_FILES);
	$temp_name=$_FILES['file']['tmp_name'];
	$file_name=time()."_".$_FILES['file']['name'];
	$new_name="images/".$file_name;
	$sum=0;
	$grade="";
	for($i=1;$i<=5;$i++)
	{
		$sum=$sum+$_POST['s'.$i];
	}
	$per=($sum*100)/500;
	if($per>=70)
	{
		$grade="DICTICTION";
	}
	elseif($per<70 && $per>=60)
	{
		$grade="FIRST CLASS";	
	}
	elseif($per<60 && $per>=50)
	{
		$grade="SECOND CLASS";	
	}
	elseif($per<50 && $per>=40)
	{
		$grade="PASS CLASS";	
	}
	else
	{
		$grade="FAIL";
	}


	if(move_uploaded_file($temp_name, $new_name))
	{
		// echo "DONE";
	}
	?>

	<h2 align="center">RESULT:</h2>
	<table border="" align="center" >
		<tr >
			<td align="center" colspan="2">
				<img src="<?php echo $new_name?>" width=100 height=100>
			</td>

		</tr>
		<tr>
			<td>
				<label>NAME:</label>
			</td>
			<td>
				<?php echo $_POST['name']?>
			</td>
		</tr>
		<tr>
			<td>
				<label>EXMA_NO:</label>
			</td>
			<td>
				<?php echo $_POST['ex_no']?>
			</td>
		</tr>
		<tr>
			<td>
				<label>SEMESTER</label>
			</td>
			<td>
				<?php echo $_POST['sem']?>
			</td>
		</tr>
		<tr>
			<td>
				<label>COURSE</label>
			</td>
			<td>
				<?php echo $_POST['course']?>
			</td>
		</tr>
		<tr>
			<td>
				<label>SUBJECT 1 MARKS:</label>
			</td>
			<td>
				<?php echo $_POST['s1']?>
			</td>
		</tr>
		<tr>
			<td>
				<label>SUBJECT 2 MARKS:</label>
			</td>
			<td>
				<?php echo $_POST['s2']?>
			</td>
		</tr>
		<tr>
			<td>
				<label>SUBJECT 3 MARKS:</label>
			</td>
			<td>
				<?php echo $_POST['s3']?>
			</td>
		</tr>
		<tr>
			<td>
				<label>SUBJECT 4 MARKS:</label>
			</td>
			<td>
				<?php echo $_POST['s4']?>
			</td>
		</tr>
		<tr>
			<td>
				<label>SUBJECT 5 MARKS:</label>
			</td>
			<td>
				<?php echo $_POST['s5']?>
			</td>
		</tr>
		<tr>
			<td>
				<label>TOTAL:</label>
			</td>
			<td>
				<?php echo $sum ?>
			</td>
		</tr>
		<tr>
			<td>
				<label>PERCENTAGE:</label>
			</td>
			<td>
				<?php echo $per?>
			</td>
		</tr>
		<tr>
			<td>
				<label>GRADE:</label>
			</td>
			<td>
				<?php echo $grade ?>
			</td>
		</tr>


			
	</table>
<?php
$file=fopen("result_data.txt","a+") or die("UNABLE TO OPEN THE FILE");

fwrite($file,"\r\nNAME:".$_POST['name']);
fwrite($file,"\r\nEXAM NO:".$_POST['ex_no']);
fwrite($file,"\r\nCOURSE:".$_POST['course']);
fwrite($file,"\r\nSEMESTER:".$_POST['sem']);
for($i=1;$i<=5;$i++)
{
fwrite($file,"\r\nSUBJECT ".$i." MARKS:".$_POST['s'.$i]);	
}
fwrite($file,"\r\nTOTAL:".$sum);
fwrite($file,"\r\nPERCENTAGE:".$per);
fwrite($file,"\r\nCLASS:".$grade);
fclose($file);
}
?>
<form action="p2.php" method="post" enctype="multipart/form-data">
	DOWNLOAD:<input type="file" name="file1">
	<input type="submit" name="submit" value="submit">

</form>
<?php
if(isset($_POST['submit']))
{
	$temp_name1=$_FILES['file1']['tmp_name'];
    $file_name1=time()."_".$_FILES['file1']['name'];
	$new_name1="result/".$file_name1;
	if(move_uploaded_file($temp_name1, $new_name1))
	{
		echo "DONE";
	}
}
?>

