<?php
	if(isset($_POST['sub']))
	{
		$m1=$_POST['m1'];
		$m2=$_POST['m2'];
		$m3=$_POST['m3'];
		$m4=$_POST['m4'];
		$m5=$_POST['m5'];
		$total=$m1+$m2+$m3+$m4+$m5;
		$per=$total*100/180;
		if($per<100 && $per>=70)
			$class="Distinction";
		elseif($per<70 && $per>=60)
			$class="First class";
		elseif($per<60 && $per>=50)
			$class="Second class";
		elseif($per<50 && $per>=40)
			$class="Pass class";
		else
			$class="Fail";

		$tmp_name=$_FILES['upload']['tmp_name'];
		$name=time()."_".$_FILES['upload']['name'];
		$folder="uploads/".$name;
		move_uploaded_file($tmp_name, $folder);
	
?>
	<table border="1" align='center'>
		<h2 align='center'> Exam Result </h2>
		<tr>
			<td>Exam No:</td>
			<td><?php echo $_POST['no'];?></td>
		</tr>
		<tr>
			<td>Course:</td>
			<td><?php echo $_POST['course'];?></td>
		</tr>
		<tr>
			<td>Semester:</td>
			<td><?php echo $_POST['sem'];?></td>
		</tr>
		<tr>
			<td>Photo:</td>
			<td><img src='<?php echo $folder;?>' alt='image' height='100' width='100'></td>
		</tr>
		<tr>
			<td>Subject 1:</td>
			<td><?php echo $_POST['m1'];?></td>
		</tr>
		<tr>
			<td>Subject 2:</td>
			<td><?php echo $_POST['m2'];?></td>
		</tr>
		<tr>
			<td>Subject 3:</td>
			<td><?php echo $_POST['m3'];?></td>
		</tr>
		<tr>
			<td>Subject 4:</td>
			<td><?php echo $_POST['m4'];?></td>
		</tr>
		<tr>
			<td>Subject 5:</td>
			<td><?php echo $_POST['m5'];?></td>
		</tr>
		<tr>
			<td>Total:</td>
			<td><?php echo $total;?></td>
		</tr>
		<tr>
			<td>Percentage:</td>
			<td><?php echo $per;?></td>
		</tr>
		<tr>
			<td>Class:</td>
			<td><?php echo $class;?></td>
		</tr>
		<?php
			$file=fopen("f1.txt","w+") or die("Could't open");
			fwrite($file,"Exam no: ".$_POST['no']);
			fwrite($file,"\r\n Course: ".$_POST['course']);
			fwrite($file,"\r\n Semester: ".$_POST['sem']);
			fwrite($file,"\r\n subject1: ".$m1);
			fwrite($file,"\r\n subject2: ".$m2);
			fwrite($file,"\r\n subject3: ".$m3);
			fwrite($file,"\r\n subject4: ".$m4);
			fwrite($file,"\r\n subject5: ".$m5);
			fwrite($file,"\r\n Total: ".$total);
			fwrite($file,"\r\n percentage: ".$per);
			fwrite($file,"\r\n Class: ".$class);
			fclose($file);
		}
			?>
			<center>
			<form action='result.php' method='post' enctype='multipart/form-data'>
				Download:
				<input type='file' name='dload'>
				<input type="submit" name="subd">
			</form>
		</center>
			<?php
			if(isset($_POST['subd'])){
				
			$tmp_name1=$_FILES['dload']['tmp_name'];
			$name1=time()."_".$_FILES['dload']['name'];
			$folder1="uploads/".$name1;
			move_uploaded_file($tmp_name1, $folder1);
			}
		

		?>

