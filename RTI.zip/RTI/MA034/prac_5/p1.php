<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<table align='center'>
		<h2 align='center'> Exam form </h2>
	<form action='result.php' method='post' enctype='multipart/form-data'>
		<tr>
			<td> Exam no </td>
			<td><input type='text' name='no'></td>
		</tr>

		<tr>
			<td> Course </td>
			<td> <select name='course'>
				<option>----Select----</option>
				<option>BCA</option>
				<option>MCA</option>
				<option>BBA</option>
				<option>MBA</option>
			</select>
		</td>
		</tr>

		<tr>
			<td> Student Photo </td>
			<td><input type='file' name='upload'></td>
		</tr>

		<tr>
			<td> Subject 1 Marks </td>
			<td><input type='text' name='m1'></td>
		</tr>

		<tr>
			<td> Subject 2 Marks </td>
			<td><input type='text' name='m2'></td>
		</tr>

		<tr>
			<td> Subject 3 Marks </td>
			<td><input type='text' name='m3'></td>
		</tr>

		<tr>
			<td> Subject 4 Marks </td>
			<td><input type='text' name='m4'></td>
		</tr>

		<tr>
			<td> Subject 5 Marks </td>
			<td><input type='text' name='m5'></td>
		</tr>

		<tr>
			<td> Semester </td>
			<td> <select name='sem'>
				<option>----Select----</option>
				<option>1</option>
				<option>2</option>
				<option>3</option>
				<option>4</option>
				<option>5</option>
				<option>6</option>
			</select>
		</td>
		</tr>

		<tr>
			<td></td>
			<td><input type='submit' name='sub'></td>
		</tr>

	</form>
</table>


</body>
</html>