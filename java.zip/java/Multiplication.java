public class Multiplication
{
	public static void main(String a[])
	{
		int no=Integer.parseInt(a[0]);
		for(int i=0;i<=10;i++)
			System.out.println(no+"*"+i+"="+no*i);
	}
}