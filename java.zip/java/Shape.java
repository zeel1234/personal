import java.util.*;

class Rectangle
{
	double l,b;
	 Rectangle()
	{
		l=1.5;
		b=2.6;

	}

	 public void area()
	 {

		    System.out.print("Area of Rectangle is :");
			double area=l*b;
		System.out.println(" "+area);
	}

}
class Triangle
{
	double b,h;
	Triangle()
	{
		b=5.2;
		h=4.1;
	}
		 public void area()
		 {

			    System.out.print("Area of Triangle is :");
				double area=0.5*b*h;
			System.out.println(" "+area);
		}

}
class Circle
{
	float r;
	Circle()
	{
		r=5.4f;
	}

	 public static float PI = 3.14f;


		 public void area()
		 {
			float area=PI*r*r;
			System.out.println(" Area of Circle = "+area);
		 }

}
public class Shape
{

   public static void main(String args[])
   {
		 Rectangle r1= new  Rectangle() ;
		 r1.area();
		 Triangle t1= new Triangle();
		 t1.area();
		 Circle c1= new Circle();
		 c1.area();


   }

}