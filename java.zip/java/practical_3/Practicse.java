import java.util.*;

class StringClass
{
	String s;
	StringClass(String str)
	{
		s=str;
	}

}
public class Practicse
{

		public static void main(String args[])
		{
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter String :");
			String str1=sc.nextLine();
			System.out.println("Enter String :");
			String str2=sc.nextLine();
		/*	System.out.println("Enter String :");
			String str3=sc.nextLine();
*/
			StringClass p1 = new StringClass(str1);
			StringClass p2 = new StringClass(str2);


			char ch1 = str1.charAt(0);//charAt method is used
			System.out.println("Character at 0 index is: "+ch1);
			System.out.println("str1 equals to str2:"+str1.equals(str2)); // equals method is used
			System.out.println("Concatenation of two String objects is : " +str1.concat(str2)); // concate method is used
			System.out.println("Length of str1:"+str1.length()); //length of string object
			System.out.println("String object in lower case :"+str1.toLowerCase()); // display string object in lower case
			System.out.println("String object in upper case :"+str1.toUpperCase()); // display string object in upper case
			int var1 = str1.compareTo( str2 );
       		System.out.println("str1 & str2 comparison: "+var1); // String object comparisons
       		System.out.println("Index of Z in str1: "+str1.indexOf('Z')); //indexOf method is used

	}
}
