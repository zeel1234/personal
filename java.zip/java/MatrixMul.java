import java.util.*;
public class MatrixMul
{
	public static void main(String args[])
	{
			int i,j,k,m,n,p,q;
			System.out.println("Enter the number of rows in matrix 1 :");
			Scanner in = new Scanner(System.in);
			m=in.n
	}
}