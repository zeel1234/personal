import java.util.*;
class Sum
{
	Scanner input= new Scanner(System.in);
	public void sum()
	{
		int a, b;

		System.out.println("Enter first Number");
		a= input.nextInt();
		System.out.println("Enter Second Number");
		b= input.nextInt();
		int c = a+b;
		System.out.println("Sum = " +c);
	}
	public int sum(int n1, int n2)
	{
		int s=n1+n2;
		return s;
	}
	public double sum(double d1, double d2)
		{
			double d =d1+d2;
			return d;
		}
	public float sum(float f1, float f2)
	{
		float f =f1+f2;
		return f;
	}
    public int sum(int n1)
    {
		return 7+ n1;
	}



}
public class Calculator
{
	public static void main(String args[])
	{
			Sum s1= new Sum() ;
			Sum s2= new Sum() ;
			/*s1.sum();
			int s = s1.sum(7,9);
			System.out.println(s);
			float f = s2.sum(1.2555f,2.55555f);
			System.out.println(f);
			double d = s1.sum(5.5,5.5);
			System.out.println(d);
*/
			int q = s1.sum(5);
			System.out.println(q);
	}

}
