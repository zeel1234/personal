import java.util.*;
public class RectangleArea
{
   public static void main(String args[])
   {
	    Scanner s = new Scanner(System.in);
	    System.out.println("Enter length of Rectangle :");
	    int l= s.nextInt();
	    System.out.println("Enter breadth of Rectangle :");
	    int b= s.nextInt();
	    System.out.println("Enter height of Rectangle :");
	    int h= s.nextInt();

	    System.out.print("Area of Rectangle is :");
		int area=l*b*h;
		System.out.println(" "+area);

   }

}