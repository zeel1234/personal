import java.util.*;

class abstract Geometry 
{
	
}