import java.util.*;


abstract class Geometry
{
	public abstract double perimeter();
}
class Square extends Geometry
{

	public double perimeter()
	{
	Scanner sc= new Scanner(System.in);
	System.out.println("Enter Length of Square");
	double len=sc.nextDouble();

	return 4*len;
	}
}

class Circle extends Geometry
{
	public static final double PI = 3.145;
	public double perimeter()
	{
	Scanner sc= new Scanner(System.in);
	System.out.println("Enter radius of Circle");
	double r=sc.nextDouble();

	return 2 * PI *r;
	}
}

class AbstractDemo
{
	public static void main(String args[])
	{
		/*Geometry g=new Square();
		double s2 = g.perimeter();
		System.out.println("Perimeter of Square " +s2);
		g=new Circle();
		double r2 = g.perimeter();
		System.out.println("Perimeter of Circle " +r2);
	*/

		Square s1 = new Square();
		double s = s1.perimeter();
		System.out.println("Perimeter of Square " +s);

		Circle c1 = new Circle();
		double r1= c1.perimeter();
		System.out.println("Perimeter of Circle " +r1);


	}
}