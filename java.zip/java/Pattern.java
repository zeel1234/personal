public class Pattern
{
	public static void main(String args[])
	{
			int i,j,k=5;
			for(i=0;i<5;i++)
			{
				for(j=0;j<5;j++)
				{
					if((i==0 || i==4) && (j>0 && j<4))
						System.out.print(" ");
					else if((i==1 || i==3 ) && (j==2))
						System.out.println(" ");
					else
						System.out.print(" A ");
				}
					System.out.println();

			}


	}
}

